<?php include "header.php";
 include "config.php"; ?>
<!-- blog -->
	<div id="blog" class="blog gallery">
		<div class="container">
			<h3 class="w3stitle"><span>EVENT</span></h3>     
			<?php
				$pass=$_GET['id'];
			
			$r=mysqli_query($conn,"select * from eventdetails where eid=$pass ");
					while($arr=mysqli_fetch_array($r))
					{?>
			<!-- <img src="<?php echo $arr[15]; ?>" >-->
			<div class="blog-agileinfo">
				<div class="col-md-7 blog-w3grid-img">
					<a href="#myModal" data-toggle="modal" class="wthree-blogimg">  
						<img src="<?php echo $arr[15]; ?>" class="img-responsive" alt=""/>
					</a>  
				</div>
				<div class="col-md-5 blog-w3grid-text"> 
					<h4><a href="#myModal" data-toggle="modal"><?php echo $arr[1]; ?></a></h4>				
					<p><?php echo  $arr[3]; ?> </p>
				</div>
				   
				<div class="clearfix"> </div>
				<div class="col-md-7">
					<br>
					<h4>Date:<?php echo  $arr[5] ; ?></h4><br>
					<h4>Venue:<?php echo  $arr[4]; ?> </h4><br>
					<h4>ticket price:<?php echo  $arr[8]; ?></h4><br>
					<h4>Available Seats: <?php echo  $arr[12]; ?> </h4><br>
					<h4>Oraganizer:<?php echo  $arr[2] ; ?></h4><br>
					<h4>contact numbers:<?php echo  "$arr[9],$arr[10],$arr[11]"; ?> </h4><br>
					<h4>Terms and condition:<?php echo  $arr[8]; ?></h4><br>
				</div>
				<div class="col-md-5" >
					<div class="col-xs-12 price-w3lgrids">
						<div class="pricing pricing-four">
							<div class="pricing-top top-four">
								<h3>Special</h3>
								<p>$100/head</p>
							</div>
							<div class="pricing-bottom w3ls"> 
								<div class="agileits-buy">
									<a class="popup-with-zoom-anim" href="#small-dialog">Book Now</a>
								</div>
							</div>
						</div>  
					</div>    
				</div>
				 
			</div> 
			 
			<?php }	   ?>		
		</div>
	</div>
	<!-- //blog --> 
 
<?php 
include "footer.php";
?>
	<!-- pop-up-grid -->
	<div id="small-dialog" class="mfp-hide">
		<div class="pop_up w3-agile">
			<div class="payment-online-form-left">
				<form action="confirm.php?id=<?php echo $pass ?>" method="post"> 
					<h4>Book ticket</h4>				
							<label>No of Tickets</label>
							<select class="form-control" name="nk">
								<option value="1">1 Ticket</option>
								<option value="2">2 Tickets</option>
								<option value="3">3 Tickets</option>
								<option value="4">4 Tickets</option>
								<option value="5">5 Tickets</option>
								<option value="6">More</option>
							</select> 
					<ul class="payment-sendbtns">
						<li><input type="reset" value="Reset"></li>
						<li><input type="submit" value="Process order"></li>
					</ul>
					<div class="clearfix"> </div>
				</form>
			</div>
		</div>
	</div>
	<!-- //pop-up-grid -->
