<!DOCTYPE html>
<html lang="en">
<head>
<title>Let's Party an Entertainment Category Bootstrap Responsive website Template | Home :: w3layouts</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Let's Party Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
	SmartPhone Compatible web template, free WebDesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Custom Theme files -->
<link href="css/bootstrap.css" type="text/css" rel="stylesheet" media="all">
<link href="css/style.css" type="text/css" rel="stylesheet" media="all">   
<link href="css/font-awesome.css" rel="stylesheet">		<!-- font-awesome icons -->    
<link rel="stylesheet" href="css/lightbox.css"> 
<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" /> 
<!-- //Custom Theme files --> 
<!-- js -->
<script src="js/jquery-2.2.3.min.js"></script>  
<!-- //js -->
<!-- web-fonts -->   
<link href="//fonts.googleapis.com/css?family=Trochut:400,400i,700" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400,400i,700,700i,900,900i" rel="stylesheet">
<!-- //web-fonts -->
	
</head>
<body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top"> 
	<!-- banner -->
	<div id="home" class="w3ls-banner w3-agilefireworks jarallax"> 
		<!-- header -->
		<div class="header-w3layouts" style="margin-bottom:80px;"> 
			<!-- Navigation -->
			<nav class="navbar navbar-default navbar-fixed-top">
				<div class="container">
					<div class="navbar-header page-scroll">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
							<span class="sr-only">Let's Party</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<h1><a class="navbar-brand" href="index.html">Let's <span>Party</span></a></h1>
					</div> 
					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse navbar-ex1-collapse">
						<ul class="nav navbar-nav navbar-right cl-effect-15">
							<!-- Hidden li included to remove active class from about link when scrolled up past about section -->
							<li><a class="page-scroll" href="index.php" data-hover="Home">Home</a></li> 
							<li><a class="page-scroll" href="addevent.php" data-hover="addevent">addevent</a></li>
							<li><a class="page-scroll" href="staff.php" data-hover="Our Staff">Our Staff</a></li>
							<li><a class="page-scroll" href="gallery.php" data-hover="Gallery">Gallery</a></li>
							<li><a class="page-scroll" href="price.php" data-hover="Prices">Prices</a></li>
							<li><a class="page-scroll" href="blog.php" data-hover="Blog">Blog</a></li>
							<li><a class="page-scroll" href="contact.php" data-hover="Contact">Contact</a></li>
							<li class="w3ls-navlog"><a class="page-scroll" href="#myModal2" data-toggle="modal" data-hover="LOGIN">LOGIN</a></li>
						</ul>
					</div>
					<!-- /.navbar-collapse -->
				</div>
				<!-- /.container -->
			</nav>  
		</div>	
		<!-- //header -->