<html>
<body>
<?php
$tic=$_POST['tic'];
$mid=$_POST['mid'];
$eid=$_POST['eid'];
$db=mysql_connect("localhost","root");
$r=mysql_select_db("eventmngt");
$r=mysql_query("select tprice from eventdetails where eid='$eid'");
while($arr=mysql_fetch_array($r))
{
	 $pr=$arr[0];
 print "priceof ticket/head=$arr[0]<br>";
}
$tot=$pr*$tic;
echo "total price for $tic tickets=$tot" 	;
	
?>
<form action="p3.php">
<input type="submit" value="confirm">
</form>
</body>