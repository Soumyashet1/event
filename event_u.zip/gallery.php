<?php 
include "header.php";
?>
<!-- gallery -->
	<div id="gallery" class="gallery">
		<div class="container"> 
			<h3 class="w3stitle">OUR <span> Gallery</span></h3>  
			<div class="gallery-w3lsrow">
				<div class="col-sm-3 col-xs-4 gallery-grids">
					<div class="w3ls-hover">
						<a href="images/g1.jpg" data-lightbox="example-set" data-title="Lorem Ipsum is simply dummy the when an unknown galley of type and scrambled it to make a type specimen.">
							<img src="images/g1.jpg" class="img-responsive zoom-img" alt=""/>
							<div class="view-caption">
								<h5>Latest Gallery</h5>
								<span class="glyphicon glyphicon-search"></span>
							</div>
						</a>
					</div>
				</div>
				<div class="col-sm-3 col-xs-4 gallery-grids">
					<div class="w3ls-hover">
						<a href="images/g2.jpg" data-lightbox="example-set" data-title="Lorem Ipsum is simply dummy the when an unknown galley of type and scrambled it to make a type specimen.">
							<img src="images/g2.jpg" class="img-responsive zoom-img" alt=""/>
							<div class="view-caption">
								<h5>Latest Gallery</h5>
								<span class="glyphicon glyphicon-search"></span>
							</div>
						</a>
					</div>
				</div>
				<div class="col-sm-3 col-xs-4 gallery-grids">
					<div class="w3ls-hover">
						<a href="images/g3.jpg" data-lightbox="example-set" data-title="Lorem Ipsum is simply dummy the when an unknown galley of type and scrambled it to make a type specimen.">
							<img src="images/g3.jpg" class="img-responsive zoom-img" alt=""/>
							<div class="view-caption">
								<h5>Latest Gallery</h5>
								<span class="glyphicon glyphicon-search"></span>
							</div>
						</a>
					</div>
				</div>
				<div class="col-sm-3 col-xs-4 gallery-grids">
					<div class="w3ls-hover">
						<a href="images/g4.jpg" data-lightbox="example-set" data-title="Lorem Ipsum is simply dummy the when an unknown galley of type and scrambled it to make a type specimen.">
							<img src="images/g4.jpg" class="img-responsive zoom-img" alt=""/>
							<div class="view-caption">
								<h5>Latest Gallery</h5>
								<span class="glyphicon glyphicon-search"></span>
							</div>
						</a>
					</div>
				</div>
				<div class="col-sm-3 col-xs-4 gallery-grids">
					<div class="w3ls-hover">
						<a href="images/g5.jpg" data-lightbox="example-set" data-title="Lorem Ipsum is simply dummy the when an unknown galley of type and scrambled it to make a type specimen.">
							<img src="images/g5.jpg" class="img-responsive zoom-img" alt=""/>
							<div class="view-caption">
								<h5>Latest Gallery</h5>
								<span class="glyphicon glyphicon-search"></span>
							</div>
						</a>
					</div>
				</div>
				<div class="col-sm-3 col-xs-4 gallery-grids">
					<div class="w3ls-hover">
						<a href="images/g6.jpg" data-lightbox="example-set" data-title="Lorem Ipsum is simply dummy the when an unknown galley of type and scrambled it to make a type specimen.">
							<img src="images/g6.jpg" class="img-responsive zoom-img" alt=""/>
							<div class="view-caption">
								<h5>Latest Gallery</h5>
								<span class="glyphicon glyphicon-search"></span>
							</div>
						</a>
					</div>
				</div>
				<div class="col-sm-3 col-xs-4 gallery-grids">
					<div class="w3ls-hover">
						<a href="images/g7.jpg" data-lightbox="example-set" data-title="Lorem Ipsum is simply dummy the when an unknown galley of type and scrambled it to make a type specimen.">
							<img src="images/g7.jpg" class="img-responsive zoom-img" alt=""/>
							<div class="view-caption">
								<h5>Latest Gallery</h5>
								<span class="glyphicon glyphicon-search"></span>
							</div>
						</a>
					</div>
				</div>
				<div class="col-sm-3 col-xs-4 gallery-grids">
					<div class="w3ls-hover">
						<a href="images/g8.jpg" data-lightbox="example-set" data-title="Lorem Ipsum is simply dummy the when an unknown galley of type and scrambled it to make a type specimen.">
							<img src="images/g8.jpg" class="img-responsive zoom-img" alt=""/>
							<div class="view-caption">
								<h5>Latest Gallery</h5>
								<span class="glyphicon glyphicon-search"></span>
							</div>
						</a>
					</div>
				</div>  
				<div class="clearfix"> </div> 
			</div>
			<!--  light box js -->
			<script src="js/lightbox-plus-jquery.min.js"> </script> 
			<!-- //light box js--> 
		</div> 
	</div>
	<!-- //gallery --> 
 
<?php 
include "footer.php";
?>