
<form action="p1.php" method="post" enctype="multipart/form-data">
    <input type="text" name="ename" placeholder="Event name" required="">
	<input type="text" name="eorg" placeholder="organizer name" required="">
	<textarea name="desc" placeholder="Event name" required=""></textarea>
	<input type="text" name="venue" placeholder="venue" required="">
	<input type="text" name="estartd" placeholder="Event start date" required="">
	<input type="text" name="eendd" placeholder="Event end date" required="">
	<input type="text" name="eurl" placeholder="Event url" required="">
	<input type="text" name="tprice" placeholder="Ticket price" required="">
	<input type="text" name="cno1" placeholder="contact number 1" required="">
	<input type="text" name="cno2" placeholder="contact number 2" required="">
	<input type="text" name="cno3" placeholder="contact number 3" required="">
	<input type="number" name="seats" placeholder="total seats" required="">
	<input type="text" name="terms" placeholder="Terms and conditions" required=""> 
	<input type="text" name="bookurl" placeholder="Booking url" required="">
	<input  type="file" name="image" required="">
<div class="w3ls-submit"> 
<input class="register" type="submit" value="book">  
</div>
</form> 
