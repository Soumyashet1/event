<html>
<body>
<form action="p2.php" method="post">
number of tickets<input type="text" name="tic" placeholder="Event name" required="">
mid<input type="text" name="mid" placeholder="Event name" required=""> 
eid<input type="text" name="eid" placeholder="Event name" required="">
<div class="w3ls-submit"> 
<input class="register" type="submit" value="book">  
</div>
</form> </body>
</html>