<?php 
$servername = "localhost";
$user ="root";
$pass = "Aissel@123";
$dbname = "eventmngt";
$conn = new mysqli($servername, $user, $pass, $dbname);?>