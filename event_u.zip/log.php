<html>
<body>
<?php
$a=$_POST['ld'];
$b=$_POST['lpd'];
include "config.php";
$r=mysqli_query($conn,"select * from members where eid='$a' and paswd='$b' ");
if(mysqli_num_rows($r)>0)
{			 echo "correct";
			 }
	else
{
			 echo "wrong";
			
}	 ?>
 </body>
</html>