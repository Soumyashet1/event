<?php 
include "header.php";
?>
		<!-- banner-text -->
		<div class="banner-text"> 
			<h2>Happy New Year</h2>
			<p>Mauris ex nulla aliquam ornare facilisis nec convallis pulvinar a non nunc non leo sollicitudin, Lorem ipsum dolor sit amet.</p>
			<!-- timer -->
			<div class="agileits-timer"> 
				<div class="clock">
					<div class="column days">
						<div class="timer" id="days"></div>
						<div class="text">Days</div>
					</div>
					<div class="timer days"></div>
					<div class="column">
						<div class="timer" id="hours"></div>
						<div class="text">Hours</div>
					</div>
					<div class="timer"></div>
					<div class="column">
						<div class="timer" id="minutes"></div>
						<div class="text">Minutes</div>
					</div>
					<div class="timer"></div>
					<div class="column">
						<div class="timer" id="seconds"></div>
						<div class="text">Seconds</div>
					</div>
					<div class="clearfix"> </div>
				</div>	 
			</div>
			<!-- //timer --> 
			<a href="#small-dialog" class="wthree-btn popup-with-zoom-anim">Get Your Entry Ticket </a> 
		</div> 
		<!-- //banner-text -->   
	</div>	
	<!-- //banner --> 
	<!-- welcome -->
	<div class="welcome">    
		<div class="welcome-agileinfo">
			<div class="col-sm-6 col-xs-6 welcome-w3left">
				<div class="col-xs-3 welcome-w3limg">
					<i class="fa fa-calendar-plus-o" aria-hidden="true"></i>
				</div>
				<div class="col-xs-9 welcome-w3ltext"> 
					<p>When</p>
					<h4>31st DEC 2016</h4>
					<h6>Starting at : 10:00 pm </h6>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="col-sm-6 col-xs-6 welcome-w3right">
				<div class="col-xs-9 welcome-w3ltext"> 
					<p>Where</p>
					<h4>LONDON, UK</h4>
					<h6>MTJ Club, 412 New Green Road </h6>
				</div>
				<div class="col-xs-3 welcome-w3limg">
					<i class="fa fa-street-view" aria-hidden="true"></i>
				</div> 
				<div class="clearfix"> </div>
			</div> 
			<div class="clearfix"> </div>
		</div> 
	</div>
	<!-- //welcome -->
	<!-- services -->
<?php include "config.php"; ?>
	<div id="services" class="services">
		<div class="container">  
			<h3 class="w3stitle"><span>Recent Events</span></h3>  
			<div class="services-w3ls-row">
				<?php $r=mysqli_query($conn,"select * from eventdetails");
					while($arr=mysqli_fetch_array($r))
					{?>
					 <div class="col-md-3 col-sm-3 col-xs-6 services-grid agileits-w3layouts">
					<span class="glyphicon glyphicon-home effect-1" aria-hidden="true"></span>
					<h4><?php echo  $arr[1]; ?></h4>
				    
					<h5>Date:<?php echo $arr[5]; ?></h5>
					<h5>Venue:<?php echo $arr[4]; ?></h5>
					<h5>seats:<?php echo $arr[12]; ?></h5>
					<div class="agileits-buy">
					<a href="single.php?id=<?php echo $arr[0]; ?>">Book Now</a>
					</div>
				</div>
					<?php }	   ?>			
				<div class="clearfix"> </div>
			</div>  
		</div>
	</div>
	<!-- //services -->
	<!-- video -->
	<div class="video-agileits jarallax">
		<div class="video">
			<div class="container"> 
				<div class="col-md-6 video-left">
					<h3 class="w3stitle w3stitle1">About<span> US</span></h3>  
					<h4>Itaque earum rerum hic tenetur a sapiente delectus reiciendis maiores alias consequatur aut </h4> 
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed tincidunt lorem sed velit fermentum lobortis. Fusce eu semper lacus, eget placerat mauris. Sed lectus tellus, sodales id elit a, feugiat porttitor nulla. Sed porta magna vitae nisl vulputate lacinia. Morbi malesuada sollicitudin tortor, vitae pharetra nunc lacinia eget.</p>
				</div> 
				<div class="col-md-6 video-right"> 
					<a class="play-icon popup-with-zoom-anim" href="#small-dialog2">
						<span class="fa fa-play-circle-o"> </span>
					</a> 
					<div id="small-dialog2" class="mfp-hide">
						<div class="pop_up w3-agile">
							<iframe src="https://www.youtube.com/embed/9JX4hCTuiEw"></iframe>
						</div>   
					</div> 
				</div>
			</div>
		</div>
	</div>
	<!-- //video -->

	
	
	<!-- testimonials -->
	<div class="testimonials team">
		<div class="container">
			<h3 class="w3stitle">What <span> People say</span></h3>     
			<div class="flexslider">
				<ul class="slides">
					<li>
						<div class="testi-three-grids"> 
							<div class="testi-left">
								<img src="images/t5.jpg" alt=" " class="img-responsive" />
							</div>
							<div class="testi-right">
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce congue tempor nisi sed luctus. Vestibulum semper quis enim vitae posuere. Vestibulum ac odio nec lorem commodo. </p>
								<h4>Douglas Joe	- <span>Adipiscing</span></h4> 
							</div>
							<div class="clearfix"> </div>
						</div>
					</li>
					<li>
						<div class="testi-three-grids"> 
							<div class="testi-left">
								<img src="images/t6.jpg" alt=" " class="img-responsive" />
							</div>
							<div class="testi-right">
								<p>Fusce congue tempor nisi sed luctus. Vestibulum semper quis enim vitae posuere. Lorem ipsum dolor sit amet, consectetur adipiscing elit.  Vestibulum ac odio nec lorem commodo. </p>
								<h4>Laura Hill	- <span>Lorem ipsum</span></h4> 
							</div>
							<div class="clearfix"> </div>
						</div> 
					</li>
					<li>
						<div class="testi-three-grids"> 
							<div class="testi-left">
								<img src="images/t7.jpg" alt=" " class="img-responsive" />
							</div>
							<div class="testi-right">
								<p>Vestibulum semper quis enim vitae posuere. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce congue tempor nisi sed luctus. Vestibulum ac odio nec lorem commodo. </p>
								<h4>Christopher	- <span>Fusce congue</span></h4> 
							</div>
							<div class="clearfix"> </div>
						</div> 
					</li>
				</ul>
			</div> 
			<!-- FlexSlider js -->
			<script defer src="js/jquery.flexslider.js"></script>
			<script type="text/javascript">
				$(window).load(function(){
				  $('.flexslider').flexslider({
					animation: "slide",
					start: function(slider){
					  $('body').removeClass('loading');
					}
				  });
				});
			</script>
			<!-- //FlexSlider js -->
		</div>
	</div>
	<!-- //testimonials -->

	<!-- subscribe -->
	<div class="subscribe wthree-sub jarallax">  
		<div class="subscribe-agileinfo">  
			<div class="container"> 
				<div class="col-sm-6 sub-w3lsleft"> 
					<h3 class="w3stitle">Subscribe <span> Newsletter</span></h3>   
					<p>Sed tincidunt lorem sed velit lacus ornare <a href="">Privacy policy</a>.</p>			
				</div>
				<div class="col-sm-6 sub-w3lsright">
					<form action="#" method="post"> 
						<input type="email" name="email" placeholder="Enter your Email..." required="">
						<input type="submit" value="Subscribe">
						<div class="clearfix"> </div>
					</form>  
				</div>
				<div class="clearfix"></div> 
			</div>
		</div>
	</div>
	<!-- //subscribe -->
	
	<!-- features -->
	<div class="features">
		<div class="container">   
			<div class="wthree-features-row">
				<div class="col-md-3 col-xs-6 features-w3grid">
					<div class="col-xs-4 features-w3lleft">
						<i class="fa fa-map-marker" aria-hidden="true"></i>
					</div>
					<div class="col-xs-8 features-w3lright"> 
						<p>LOCATION</p>
						<h4>LONDON, UK</h4>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="col-md-3 col-xs-6 features-w3grid">
					<div class="col-xs-4 features-w3lleft">
						<i class="fa fa-ticket" aria-hidden="true"></i>
					</div>
					<div class="col-xs-8 features-w3lright"> 
						<p>REMAINING</p>
						<h4>50 Tickets</h4>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="col-md-3 col-xs-6 features-w3grid">
					<div class="col-xs-4 features-w3lleft">
						<i class="fa fa-calendar-plus-o" aria-hidden="true"></i>
					</div>
					<div class="col-xs-8 features-w3lright"> 
						<p>EVENTS</p>
						<h4>20+ Events</h4>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="col-md-3 col-xs-6 features-w3grid">
					<div class="col-xs-4 features-w3lleft">
						<i class="fa fa-users" aria-hidden="true"></i> 
					</div>
					<div class="col-xs-8 features-w3lright"> 
						<p>CUSTOMERS</p>
						<h4>12,000+</h4>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<!-- //features -->
<?php 
include "footer.php";
?>	