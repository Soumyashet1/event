<?php 
include "header.php";
?>
	<!-- blog -->
	<div id="blog" class="blog gallery">
		<div class="container">  
			<h3 class="w3stitle">Our<span> Blog</span></h3>     
			<div class="blog-agileinfo">
				<div class="col-md-7 blog-w3grid-img">
					<a href="#myModal" data-toggle="modal" class="wthree-blogimg">  
						<img src="images/img1.jpg" class="img-responsive" alt=""/>
					</a>  
				</div>
				<div class="col-md-5 blog-w3grid-text"> 
					<h4><a href="#myModal" data-toggle="modal">Soluta vum nobis</a></h4>
					<h6>By <a href="#"> Admin</a> - Nov 25th, 2016 </h6>
					<p>Sed interdum interdum accumsan. Aenean nec purus ac orci finibus facilisis. In sit amet placerat nisl, in auctor sapien. Donec ultricies faucibus ante in mattis earum rerum delectus in auctor sapien. </p>
				</div> 
				<div class="clearfix"> </div>
			</div> 
			<div class="blog-agileinfo blog-agileinfo-mdl">
				<div class="col-md-7 blog-w3grid-img blog-img-rght">
					<a href="#myModal" data-toggle="modal" class="wthree-blogimg">  
						<img src="images/img2.jpg" class="img-responsive" alt=""/>
					</a>  
				</div>
				<div class="col-md-5 blog-w3grid-text"> 
					<h4><a href="#myModal" data-toggle="modal">Aenean nec purus ac</a></h4>
					<h6>By <a href="#"> Admin</a> - Dec 31st, 2015 </h6>
					<p>Sed interdum interdum accumsan. Aenean nec purus ac orci finibus facilisis. In sit amet placerat nisl, in auctor sapien. Donec ultricies faucibus ante in mattis earum rerum hic a sapiente delectus. </p>
				</div> 
				<div class="clearfix"> </div>
			</div> 
			<div class="blog-agileinfo">
				<div class="col-md-7 blog-w3grid-img">
					<a href="#myModal" data-toggle="modal" class="wthree-blogimg">  
						<img src="images/img3.jpg" class="img-responsive" alt=""/>
					</a>  
				</div>
				<div class="col-md-5 blog-w3grid-text"> 
					<h4><a href="#myModal" data-toggle="modal">Mattis earum rerum</a></h4>
					<h6>By <a href="#"> Admin</a> - Dec 25th, 2016 </h6>
					<p>Sed interdum interdum accumsan. Aenean nec purus ac orci finibus facilisis. In sit amet placerat nisl, in auctor sapien. Donec ultricies faucibus ante rerum hic a sapiente delectus in auctor sapien. </p>
				</div> 
				<div class="clearfix"> </div>
			</div> 
		</div>
	</div>
	<!-- //blog --> 
 
<?php 
include "footer.php";
?>